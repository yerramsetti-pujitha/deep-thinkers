import { GoogleGenAI } from "@google/genai";
import { User, HealthLog } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export async function getCoachAdvice(user: User, logs: HealthLog[], userMessage: string) {
  const model = "gemini-3-flash-preview";
  
  const systemInstruction = `
    You are AroMi, an adaptive health and wellness coach. 
    Your goal is to provide personalized, encouraging, and actionable advice.
    
    User Profile:
    - Name: ${user.name}
    - Age: ${user.age}
    - Weight: ${user.weight}kg
    - Height: ${user.height}cm
    - Goals: ${user.goals}
    
    Recent Logs:
    ${logs.map(l => `[${l.timestamp}] ${l.type}: ${l.value}`).join('\n')}
    
    Guidelines:
    1. Be concise and empathetic.
    2. Adjust recommendations based on the user's mood and energy levels if logged.
    3. If the user is struggling, offer small, manageable steps.
    4. Use Markdown for formatting.
    5. Always maintain a professional yet friendly tone.
  `;

  const response = await ai.models.generateContent({
    model,
    contents: userMessage,
    config: {
      systemInstruction,
    },
  });

  return response.text;
}
