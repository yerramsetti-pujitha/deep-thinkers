import React, { useState, useEffect } from 'react';
import { User, HealthLog, FitnessData, NutritionData, SleepData, MoodData } from './types';
import { 
  Activity, 
  Utensils, 
  Moon, 
  Smile, 
  Plus, 
  MessageSquare, 
  ChevronRight,
  TrendingUp,
  User as UserIcon,
  Settings,
  LogOut,
  Dumbbell,
  Coffee,
  Brain
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts';
import Markdown from 'react-markdown';
import { getCoachAdvice } from './services/geminiService';
import { format } from 'date-fns';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// --- Components ---

const Card = ({ children, className }: { children: React.ReactNode; className?: string }) => (
  <div className={cn("glass rounded-2xl p-6 card-hover", className)}>
    {children}
  </div>
);

const Button = ({ 
  children, 
  onClick, 
  variant = 'primary', 
  className,
  disabled
}: { 
  children: React.ReactNode; 
  onClick?: () => void; 
  variant?: 'primary' | 'secondary' | 'ghost';
  className?: string;
  disabled?: boolean;
}) => {
  const variants = {
    primary: "bg-brand-600 text-white hover:bg-brand-700 shadow-sm",
    secondary: "bg-white text-stone-900 border border-stone-200 hover:bg-stone-50",
    ghost: "text-stone-600 hover:bg-stone-100"
  };

  return (
    <button 
      onClick={onClick}
      disabled={disabled}
      className={cn(
        "px-4 py-2 rounded-xl font-medium transition-all active:scale-95 disabled:opacity-50 disabled:pointer-events-none",
        variants[variant],
        className
      )}
    >
      {children}
    </button>
  );
};

const Input = ({ label, ...props }: { label: string } & React.InputHTMLAttributes<HTMLInputElement>) => (
  <div className="space-y-1">
    <label className="text-sm font-medium text-stone-600 ml-1">{label}</label>
    <input 
      {...props}
      className="w-full px-4 py-2 rounded-xl border border-stone-200 focus:outline-none focus:ring-2 focus:ring-brand-500/20 focus:border-brand-500 transition-all"
    />
  </div>
);

// --- Main App ---

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [logs, setLogs] = useState<HealthLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [showOnboarding, setShowOnboarding] = useState(false);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'coach' | 'logs'>('dashboard');

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [userRes, logsRes] = await Promise.all([
        fetch('/api/user'),
        fetch('/api/logs')
      ]);
      const userData = await userRes.json();
      const logsData = await logsRes.json();
      
      setUser(userData);
      setLogs(logsData);
      if (!userData) setShowOnboarding(true);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleOnboarding = async (data: Partial<User>) => {
    const res = await fetch('/api/user', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    if (res.ok) {
      setShowOnboarding(false);
      fetchData();
    }
  };

  const addLog = async (type: HealthLog['type'], value: any) => {
    if (!user) return;
    const res = await fetch('/api/logs', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ user_id: user.id, type, value })
    });
    if (res.ok) {
      fetchData();
    }
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-stone-50">
      <div className="flex flex-col items-center gap-4">
        <div className="w-12 h-12 border-4 border-brand-500 border-t-transparent rounded-full animate-spin" />
        <p className="text-stone-500 font-medium">Loading your wellness journey...</p>
      </div>
    </div>
  );

  if (showOnboarding) return <Onboarding onComplete={handleOnboarding} />;

  return (
    <div className="min-h-screen bg-stone-50 flex flex-col md:flex-row">
      {/* Sidebar */}
      <nav className="w-full md:w-64 bg-white border-r border-stone-200 p-6 flex flex-col gap-8">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-brand-600 rounded-xl flex items-center justify-center text-white">
            <Activity size={24} />
          </div>
          <h1 className="text-xl font-bold font-display tracking-tight">AroMi AI</h1>
        </div>

        <div className="flex flex-col gap-2 flex-1">
          <NavButton 
            active={activeTab === 'dashboard'} 
            onClick={() => setActiveTab('dashboard')}
            icon={<TrendingUp size={20} />}
            label="Dashboard"
          />
          <NavButton 
            active={activeTab === 'coach'} 
            onClick={() => setActiveTab('coach')}
            icon={<Brain size={20} />}
            label="AI Coach"
          />
          <NavButton 
            active={activeTab === 'logs'} 
            onClick={() => setActiveTab('logs')}
            icon={<Activity size={20} />}
            label="Activity Logs"
          />
        </div>

        <div className="pt-6 border-t border-stone-100">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-full bg-stone-100 flex items-center justify-center text-stone-500">
              <UserIcon size={20} />
            </div>
            <div>
              <p className="text-sm font-semibold">{user?.name}</p>
              <p className="text-xs text-stone-500">{user?.goals}</p>
            </div>
          </div>
          <Button variant="ghost" className="w-full flex items-center gap-2 justify-start text-red-500 hover:bg-red-50">
            <LogOut size={18} />
            Sign Out
          </Button>
        </div>
      </nav>

      {/* Main Content */}
      <main className="flex-1 p-6 md:p-10 overflow-y-auto">
        <AnimatePresence mode="wait">
          {activeTab === 'dashboard' && (
            <motion.div
              key="dashboard"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-8"
            >
              <header className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                  <h2 className="text-3xl font-bold font-display">Welcome back, {user?.name}!</h2>
                  <p className="text-stone-500">Here's how your health journey is looking today.</p>
                </div>
                <div className="flex gap-2">
                  <QuickLog onLog={addLog} />
                </div>
              </header>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                <StatCard 
                  title="Daily Steps" 
                  value="8,432" 
                  unit="steps" 
                  trend="+12%" 
                  icon={<Activity className="text-blue-500" />} 
                />
                <StatCard 
                  title="Calories" 
                  value="1,850" 
                  unit="kcal" 
                  trend="-5%" 
                  icon={<Utensils className="text-orange-500" />} 
                />
                <StatCard 
                  title="Sleep" 
                  value="7.5" 
                  unit="hours" 
                  trend="+0.5h" 
                  icon={<Moon className="text-indigo-500" />} 
                />
                <StatCard 
                  title="Mood" 
                  value="8" 
                  unit="/ 10" 
                  trend="Stable" 
                  icon={<Smile className="text-yellow-500" />} 
                />
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <Card className="lg:col-span-2">
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="text-lg font-bold">Activity Progress</h3>
                    <select className="bg-stone-50 border-none text-sm font-medium focus:ring-0">
                      <option>Last 7 Days</option>
                      <option>Last 30 Days</option>
                    </select>
                  </div>
                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={chartData(logs)}>
                        <defs>
                          <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#22c55e" stopOpacity={0.1}/>
                            <stop offset="95%" stopColor="#22c55e" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f1f1" />
                        <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fontSize: 12, fill: '#888'}} />
                        <YAxis axisLine={false} tickLine={false} tick={{fontSize: 12, fill: '#888'}} />
                        <Tooltip 
                          contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                        />
                        <Area type="monotone" dataKey="value" stroke="#22c55e" fillOpacity={1} fill="url(#colorValue)" strokeWidth={2} />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </Card>

                <Card className="bg-brand-600 text-white border-none">
                  <div className="flex items-center gap-2 mb-4">
                    <Brain size={24} />
                    <h3 className="text-lg font-bold">AI Coach Tip</h3>
                  </div>
                  <p className="text-brand-50 mb-6 leading-relaxed">
                    "Based on your 7.5 hours of sleep, your energy levels should be peak around 11 AM. Try tackling your most intense workout then!"
                  </p>
                  <Button 
                    variant="secondary" 
                    className="w-full bg-white/10 border-white/20 text-white hover:bg-white/20"
                    onClick={() => setActiveTab('coach')}
                  >
                    Chat with AroMi
                  </Button>
                </Card>
              </div>
            </motion.div>
          )}

          {activeTab === 'coach' && (
            <motion.div
              key="coach"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              className="h-full flex flex-col"
            >
              <AICoach user={user!} logs={logs} />
            </motion.div>
          )}

          {activeTab === 'logs' && (
            <motion.div
              key="logs"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-6"
            >
              <h2 className="text-2xl font-bold font-display">Activity History</h2>
              <div className="space-y-4">
                {logs.length === 0 ? (
                  <Card className="text-center py-12">
                    <p className="text-stone-500">No logs yet. Start tracking your progress!</p>
                  </Card>
                ) : (
                  logs.map(log => (
                    <LogItem key={log.id} log={log} />
                  ))
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>
    </div>
  );
}

// --- Sub-components ---

function NavButton({ active, onClick, icon, label }: { active: boolean; onClick: () => void; icon: React.ReactNode; label: string }) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium",
        active ? "bg-brand-50 text-brand-700" : "text-stone-500 hover:bg-stone-50"
      )}
    >
      {icon}
      {label}
    </button>
  );
}

function StatCard({ title, value, unit, trend, icon }: { title: string; value: string; unit: string; trend: string; icon: React.ReactNode }) {
  return (
    <Card className="flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <div className="p-2 bg-stone-50 rounded-lg">{icon}</div>
        <span className={cn(
          "text-xs font-bold px-2 py-1 rounded-full",
          trend.startsWith('+') ? "bg-green-50 text-green-600" : trend.startsWith('-') ? "bg-red-50 text-red-600" : "bg-stone-50 text-stone-600"
        )}>
          {trend}
        </span>
      </div>
      <div>
        <p className="text-sm font-medium text-stone-500">{title}</p>
        <div className="flex items-baseline gap-1">
          <span className="text-2xl font-bold">{value}</span>
          <span className="text-sm text-stone-400">{unit}</span>
        </div>
      </div>
    </Card>
  );
}

function QuickLog({ onLog }: { onLog: (type: HealthLog['type'], value: any) => void }) {
  const [isOpen, setIsOpen] = useState(false);

  const logTypes = [
    { id: 'fitness', label: 'Workout', icon: <Dumbbell size={18} />, color: 'blue' },
    { id: 'nutrition', label: 'Meal', icon: <Coffee size={18} />, color: 'orange' },
    { id: 'sleep', label: 'Sleep', icon: <Moon size={18} />, color: 'indigo' },
    { id: 'mood', label: 'Mood', icon: <Smile size={18} />, color: 'yellow' },
  ];

  return (
    <div className="relative">
      <Button onClick={() => setIsOpen(!isOpen)} className="flex items-center gap-2">
        <Plus size={20} />
        Quick Log
      </Button>
      
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.9, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 10 }}
            className="absolute right-0 mt-2 w-48 bg-white rounded-2xl shadow-xl border border-stone-100 p-2 z-50"
          >
            {logTypes.map(type => (
              <button
                key={type.id}
                onClick={() => {
                  // Simplified logging for demo
                  onLog(type.id as any, { note: `Logged ${type.label}` });
                  setIsOpen(false);
                }}
                className="w-full flex items-center gap-3 px-4 py-3 hover:bg-stone-50 rounded-xl transition-all text-sm font-medium text-stone-700"
              >
                <div className={cn("p-1.5 rounded-lg", `bg-${type.color}-50 text-${type.color}-600`)}>
                  {type.icon}
                </div>
                {type.label}
              </button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}

function LogItem({ log }: { log: HealthLog }) {
  const data = JSON.parse(log.value);
  const icons = {
    fitness: <Dumbbell className="text-blue-500" />,
    nutrition: <Coffee className="text-orange-500" />,
    sleep: <Moon className="text-indigo-500" />,
    mood: <Smile className="text-yellow-500" />
  };

  return (
    <Card className="flex items-center justify-between py-4">
      <div className="flex items-center gap-4">
        <div className="p-2 bg-stone-50 rounded-xl">
          {icons[log.type]}
        </div>
        <div>
          <p className="font-bold capitalize">{log.type}</p>
          <p className="text-sm text-stone-500">{data.note || 'No additional details'}</p>
        </div>
      </div>
      <p className="text-xs font-medium text-stone-400">
        {format(new Date(log.timestamp), 'MMM d, h:mm a')}
      </p>
    </Card>
  );
}

function AICoach({ user, logs }: { user: User; logs: HealthLog[] }) {
  const [messages, setMessages] = useState<{ role: 'user' | 'ai'; content: string }[]>([
    { role: 'ai', content: `Hi ${user.name}! I'm AroMi, your wellness coach. How can I help you reach your goals today?` }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  const handleSend = async () => {
    if (!input.trim()) return;
    
    const userMsg = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userMsg }]);
    setIsTyping(true);

    try {
      const advice = await getCoachAdvice(user, logs, userMsg);
      setMessages(prev => [...prev, { role: 'ai', content: advice || "I'm sorry, I couldn't process that. Let's try again." }]);
    } catch (err) {
      console.error(err);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="h-full flex flex-col gap-4">
      <div className="flex-1 overflow-y-auto space-y-4 pr-2">
        {messages.map((msg, i) => (
          <div key={i} className={cn(
            "flex",
            msg.role === 'user' ? "justify-end" : "justify-start"
          )}>
            <div className={cn(
              "max-w-[80%] p-4 rounded-2xl",
              msg.role === 'user' ? "bg-brand-600 text-white" : "bg-white border border-stone-100 shadow-sm"
            )}>
              <div className="prose prose-sm max-w-none prose-stone">
                <Markdown>{msg.content}</Markdown>
              </div>
            </div>
          </div>
        ))}
        {isTyping && (
          <div className="flex justify-start">
            <div className="bg-white border border-stone-100 p-4 rounded-2xl shadow-sm flex gap-1">
              <span className="w-1.5 h-1.5 bg-stone-300 rounded-full animate-bounce" />
              <span className="w-1.5 h-1.5 bg-stone-300 rounded-full animate-bounce [animation-delay:0.2s]" />
              <span className="w-1.5 h-1.5 bg-stone-300 rounded-full animate-bounce [animation-delay:0.4s]" />
            </div>
          </div>
        )}
      </div>

      <div className="flex gap-2 p-2 bg-white rounded-2xl border border-stone-100 shadow-lg">
        <input 
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyPress={e => e.key === 'Enter' && handleSend()}
          placeholder="Ask AroMi anything..."
          className="flex-1 bg-transparent border-none focus:ring-0 px-4 py-2"
        />
        <Button onClick={handleSend} disabled={isTyping}>
          <MessageSquare size={20} />
        </Button>
      </div>
    </div>
  );
}

function Onboarding({ onComplete }: { onComplete: (data: Partial<User>) => void }) {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    age: 25,
    weight: 70,
    height: 175,
    goals: ''
  });

  return (
    <div className="min-h-screen bg-stone-50 flex items-center justify-center p-6">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-md w-full bg-white rounded-3xl shadow-xl p-8 space-y-8"
      >
        <div className="text-center">
          <div className="w-16 h-16 bg-brand-600 rounded-2xl flex items-center justify-center text-white mx-auto mb-4">
            <Activity size={32} />
          </div>
          <h1 className="text-2xl font-bold font-display">Welcome to AroMi</h1>
          <p className="text-stone-500">Let's set up your personalized health profile.</p>
        </div>

        <div className="space-y-6">
          {step === 1 && (
            <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-4">
              <Input 
                label="What's your name?" 
                value={formData.name} 
                onChange={e => setFormData({ ...formData, name: e.target.value })} 
                placeholder="John Doe"
              />
              <Input 
                label="How old are you?" 
                type="number" 
                value={formData.age} 
                onChange={e => setFormData({ ...formData, age: parseInt(e.target.value) })} 
              />
              <Button onClick={() => setStep(2)} className="w-full py-3" disabled={!formData.name}>
                Continue
              </Button>
            </motion.div>
          )}

          {step === 2 && (
            <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <Input 
                  label="Weight (kg)" 
                  type="number" 
                  value={formData.weight} 
                  onChange={e => setFormData({ ...formData, weight: parseFloat(e.target.value) })} 
                />
                <Input 
                  label="Height (cm)" 
                  type="number" 
                  value={formData.height} 
                  onChange={e => setFormData({ ...formData, height: parseFloat(e.target.value) })} 
                />
              </div>
              <Input 
                label="What are your main goals?" 
                value={formData.goals} 
                onChange={e => setFormData({ ...formData, goals: e.target.value })} 
                placeholder="e.g. Lose weight, build muscle, better sleep"
              />
              <div className="flex gap-2">
                <Button variant="secondary" onClick={() => setStep(1)} className="flex-1">Back</Button>
                <Button onClick={() => onComplete(formData)} className="flex-[2] py-3">Get Started</Button>
              </div>
            </motion.div>
          )}
        </div>

        <div className="flex justify-center gap-2">
          <div className={cn("w-2 h-2 rounded-full transition-all", step === 1 ? "bg-brand-600 w-6" : "bg-stone-200")} />
          <div className={cn("w-2 h-2 rounded-full transition-all", step === 2 ? "bg-brand-600 w-6" : "bg-stone-200")} />
        </div>
      </motion.div>
    </div>
  );
}

// --- Helpers ---

function chartData(logs: HealthLog[]) {
  // Mock data for visualization if no logs
  if (logs.length === 0) {
    return [
      { name: 'Mon', value: 4000 },
      { name: 'Tue', value: 3000 },
      { name: 'Wed', value: 2000 },
      { name: 'Thu', value: 2780 },
      { name: 'Fri', value: 1890 },
      { name: 'Sat', value: 2390 },
      { name: 'Sun', value: 3490 },
    ];
  }
  
  // Group logs by day and count (simplified)
  const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const grouped = logs.reduce((acc: any, log) => {
    const day = days[new Date(log.timestamp).getDay()];
    acc[day] = (acc[day] || 0) + 1;
    return acc;
  }, {});

  return days.map(day => ({ name: day, value: (grouped[day] || 0) * 1000 }));
}
