export interface User {
  id: number;
  name: string;
  age: number;
  weight: number;
  height: number;
  goals: string;
  created_at: string;
}

export interface HealthLog {
  id: number;
  user_id: number;
  type: 'fitness' | 'nutrition' | 'sleep' | 'mood';
  value: string; // JSON string
  timestamp: string;
}

export interface FitnessData {
  exercise: string;
  duration: number; // minutes
  intensity: 'low' | 'medium' | 'high';
}

export interface NutritionData {
  meal: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
}

export interface SleepData {
  hours: number;
  quality: number; // 1-10
}

export interface MoodData {
  level: number; // 1-10
  note: string;
}
